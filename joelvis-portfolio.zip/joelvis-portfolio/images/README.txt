Put your photos, CAD screenshots, wiring diagrams and scope captures in this folder.
Send them to Claude and it will swap them in for the [bracketed] placeholders.
